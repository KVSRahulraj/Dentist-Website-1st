
import React, { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

const faqs = [
  {
    question: 'Do you offer EMI or financing for dental procedures?',
    answer: 'Yes, we provide 0% interest EMI options through leading financial partners like Bajaj Finserv and major credit cards for all treatments above ₹20,000.'
  },
  {
    question: 'Is the clinic open on Sundays for emergencies?',
    answer: 'Absolutely. We understand that emergencies don’t wait. We are open every Sunday from 10:00 AM to 4:00 PM for all services.'
  },
  {
    question: 'Which corporate insurance partners are you associated with?',
    answer: 'We partner with over 15 major insurance providers including HDFC ERGO, Star Health, and ICICI Lombard. Please bring your insurance card during your visit.'
  },
  {
    question: 'How do Invisible Aligners compare to traditional braces?',
    answer: 'Invisible aligners are virtually undetectable, removable for eating, and significantly more comfortable. They are the preferred choice for working professionals in Hyderabad.'
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6 grid md:grid-cols-2 gap-16 items-start">
        <div>
          <h4 className="text-gold font-bold tracking-[0.2em] uppercase text-sm mb-4">Support</h4>
          <h2 className="text-4xl md:text-5xl font-bold text-navy mb-8">Frequently Asked Questions</h2>
          <p className="text-slate-600 mb-8 leading-relaxed">
            Can't find what you're looking for? Reach out to us via WhatsApp or phone. We're here to help you make the best decision for your oral health.
          </p>
          <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
            <h5 className="font-bold text-navy mb-2">Still have questions?</h5>
            <p className="text-slate-500 text-sm mb-6">Our help team is available 24/7 to answer your queries.</p>
            <button className="bg-navy text-white px-6 py-3 rounded-full hover:bg-gold transition-all text-sm font-bold">Contact Support</button>
          </div>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div 
              key={i} 
              className={`border rounded-2xl transition-all duration-300 ${openIndex === i ? 'border-gold bg-gold/5 shadow-md' : 'border-slate-100 hover:border-gold/30'}`}
            >
              <button 
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left"
              >
                <span className={`font-bold text-lg ${openIndex === i ? 'text-navy' : 'text-slate-700'}`}>{faq.question}</span>
                <div className={`transform transition-transform duration-300 ${openIndex === i ? 'rotate-180' : 'rotate-0'}`}>
                  {openIndex === i ? <Minus className="w-5 h-5 text-gold" /> : <Plus className="w-5 h-5 text-slate-400" />}
                </div>
              </button>
              <div className={`overflow-hidden transition-all duration-300 ${openIndex === i ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
                <div className="px-6 pb-6 text-slate-600 leading-relaxed">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
