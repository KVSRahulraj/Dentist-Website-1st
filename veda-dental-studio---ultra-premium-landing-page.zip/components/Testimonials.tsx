
import React, { useState, useEffect } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';

const testimonials = [
  {
    name: 'Anjali Reddy',
    role: 'Corporate Professional',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    content: 'The "Invisible Aligners" transformed my smile without anyone noticing. The environment at Veda is ultra-premium and so relaxing.',
    stars: 5
  },
  {
    name: 'Dr. Vikram Singh',
    role: 'Local Resident',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    content: 'Painless root canal is actually painless here. Their high-tech approach saved my tooth. Best clinic in Hyderabad!',
    stars: 5
  },
  {
    name: 'Meera Kapoor',
    role: 'Designer',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200',
    content: 'The Smile Makeover gave me the confidence I needed for my business events. The doctors are highly professional.',
    stars: 5
  },
  {
    name: 'Suresh Kumar',
    role: 'Tech Lead',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200',
    content: 'Very well managed clinic. Perfect for corporate people who value time. Sunday appointments are a life-saver.',
    stars: 5
  }
];

const Testimonials: React.FC = () => {
  const [active, setActive] = useState(0);

  const next = () => setActive((prev) => (prev + 1) % testimonials.length);
  const prev = () => setActive((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));

  useEffect(() => {
    const timer = setInterval(next, 6000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="testimonials" className="py-24 bg-navy overflow-hidden">
      <div className="container mx-auto px-6 relative">
        <div className="text-center mb-16">
          <h4 className="text-gold font-bold tracking-[0.2em] uppercase text-sm mb-4">Patient Voices</h4>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">5-Star Google Reviews</h2>
          <div className="flex justify-center space-x-1 mb-8">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-6 h-6 text-gold fill-gold" />
            ))}
            <span className="text-white ml-2 font-bold">4.9/5 Rating</span>
          </div>
        </div>

        <div className="max-w-4xl mx-auto relative px-12">
          {/* Navigation */}
          <button onClick={prev} className="absolute left-0 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-gold text-white p-3 rounded-full transition-all">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button onClick={next} className="absolute right-0 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-gold text-white p-3 rounded-full transition-all">
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="relative min-h-[350px]">
            {testimonials.map((t, idx) => (
              <div 
                key={idx}
                className={`absolute inset-0 flex flex-col items-center text-center transition-all duration-700 transform ${
                  idx === active ? 'opacity-100 scale-100 translate-x-0' : 'opacity-0 scale-90 translate-x-20 pointer-events-none'
                }`}
              >
                <div className="relative mb-8">
                  <div className="absolute -top-4 -left-4 text-gold/30">
                    <Quote className="w-16 h-16" />
                  </div>
                  <img src={t.image} alt={t.name} className="w-24 h-24 rounded-full border-4 border-gold object-cover shadow-2xl mx-auto" />
                </div>
                <p className="text-xl md:text-2xl text-white/90 italic mb-8 max-w-2xl leading-relaxed">
                  "{t.content}"
                </p>
                <h4 className="text-gold font-bold text-lg">{t.name}</h4>
                <p className="text-white/50 text-sm uppercase tracking-widest">{t.role}</p>
              </div>
            ))}
          </div>

          <div className="flex justify-center space-x-2 mt-8">
            {testimonials.map((_, i) => (
              <button 
                key={i} 
                onClick={() => setActive(i)}
                className={`h-1.5 transition-all duration-300 rounded-full ${i === active ? 'w-8 bg-gold' : 'w-2 bg-white/30 hover:bg-white/50'}`}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
