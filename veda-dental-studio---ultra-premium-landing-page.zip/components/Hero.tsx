
import React from 'react';
import { MessageCircle, Calendar } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      {/* Background Image - Featuring the professional clinic environment provided */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=1920"
          alt="Veda Dental Studio - Professional Excellence"
          className="w-full h-full object-cover object-right lg:object-center transition-transform duration-1000 scale-105"
        />
        
        {/* Premium Multi-layer Overlay for Aesthetic Depth and Text Contrast */}
        {/* Dark Navy gradient on the left to ensure the white/gold text pops */}
        <div className="absolute inset-0 bg-gradient-to-r from-navy via-navy/60 to-transparent"></div>
        <div className="absolute inset-0 bg-black/5"></div>
        
        {/* Subtle Gold Accent Glow */}
        <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-gold/10 blur-[150px] rounded-full pointer-events-none"></div>
      </div>

      {/* Hero Content Wrapper */}
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          
          {/* Left Side: Branding & Value Proposition */}
          <div className="text-white max-w-xl animate-[fadeInLeft_1s_ease-out]">
            <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full border border-white/20 mb-8">
              <div className="w-2 h-2 bg-gold rounded-full animate-pulse shadow-[0_0_8px_#D4AF37]"></div>
              <span className="text-white text-[10px] font-bold uppercase tracking-[0.3em]">Excellence in Dentistry</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
              World Class<br />
              <span className="text-gold italic font-normal">Dental Artistry.</span>
            </h1>
            
            <p className="text-lg md:text-xl text-white/80 mb-10 max-w-lg leading-relaxed font-light">
              Experience the pinnacle of oral care in Hyderabad. Where cutting-edge precision meets the warmth of royal hospitality.
            </p>
            
            <div className="flex flex-wrap gap-5">
              <button className="bg-gold hover:bg-white hover:text-navy text-white px-10 py-5 rounded-full font-bold flex items-center space-x-3 transition-all transform hover:scale-105 shadow-2xl shadow-gold/20">
                <Calendar className="w-5 h-5" />
                <span>Book Appointment</span>
              </button>
              <a 
                href="https://wa.me/919876543210" 
                className="bg-navy hover:bg-white/10 backdrop-blur-md border border-gold/30 text-gold px-10 py-5 rounded-full font-bold flex items-center space-x-3 transition-all transform hover:scale-105"
              >
                <MessageCircle className="w-5 h-5 text-green-400" />
                <span>Consult on WhatsApp</span>
              </a>
            </div>
            
            {/* Social Proof */}
            <div className="mt-16 flex items-center space-x-12 opacity-80">
              <div className="flex flex-col">
                <span className="text-3xl font-bold font-serif text-white">15+</span>
                <span className="text-[10px] uppercase tracking-widest text-gold font-bold">Years Experience</span>
              </div>
              <div className="w-px h-10 bg-white/20"></div>
              <div className="flex flex-col">
                <span className="text-3xl font-bold font-serif text-white">50k+</span>
                <span className="text-[10px] uppercase tracking-widest text-gold font-bold">Happy Patients</span>
              </div>
            </div>
          </div>

          {/* Right Side: Quick Booking (Glass Card) */}
          <div className="hidden md:block animate-[fadeInRight_1.2s_ease-out]">
            <div className="glass-card p-12 rounded-[3.5rem] shadow-2xl space-y-8 max-w-md ml-auto border border-white/20 relative group">
              <div className="absolute -top-12 -right-12 w-48 h-48 bg-gold/20 rounded-full blur-[80px] pointer-events-none group-hover:bg-gold/30 transition-all duration-700"></div>
              
              <div className="relative z-10">
                <div className="mb-8">
                  <h3 className="text-2xl font-serif text-white font-bold">Fast-Track Booking</h3>
                  <div className="h-1 w-12 bg-gold mt-2 rounded-full"></div>
                </div>
                
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-white/60 text-[10px] font-bold uppercase tracking-[0.2em] ml-1">Full Name</label>
                    <input type="text" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white placeholder-white/20 focus:outline-none focus:ring-2 focus:ring-gold transition-all duration-300" placeholder="Rahul Sharma" />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-white/60 text-[10px] font-bold uppercase tracking-[0.2em] ml-1">Mobile Number</label>
                    <input type="tel" className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white placeholder-white/20 focus:outline-none focus:ring-2 focus:ring-gold transition-all duration-300" placeholder="+91" />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-white/60 text-[10px] font-bold uppercase tracking-[0.2em] ml-1">Desired Service</label>
                    <div className="relative">
                      <select className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-gold appearance-none cursor-pointer transition-all duration-300">
                        <option className="bg-navy">Smile Makeover</option>
                        <option className="bg-navy">Painless Root Canal</option>
                        <option className="bg-navy">Invisible Aligners</option>
                        <option className="bg-navy">General Checkup</option>
                      </select>
                      <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-white/30">
                        <svg className="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" /></svg>
                      </div>
                    </div>
                  </div>
                  
                  <button className="w-full bg-gold text-white font-black py-5 rounded-2xl hover:bg-white hover:text-navy transition-all duration-500 mt-6 shadow-xl shadow-gold/10 uppercase tracking-widest text-sm transform active:scale-95">
                    Submit Request
                  </button>
                  
                  <p className="text-white/40 text-[9px] text-center mt-6 uppercase tracking-[0.4em] font-medium italic">
                    Trusted by Hyderabad's Top Professionals
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Animations */}
      <style>{`
        @keyframes fadeInLeft {
          from { opacity: 0; transform: translateX(-60px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes fadeInRight {
          from { opacity: 0; transform: translateX(60px); }
          to { opacity: 1; transform: translateX(0); }
        }
      `}</style>
    </section>
  );
};

export default Hero;
